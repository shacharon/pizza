import type { Request, Response } from 'express';
import { z } from 'zod';
import { nluService } from '../services/nlu.service.js';
import { nluPolicy, Action } from '../services/nlu.policy.js';
import { getRestaurantsProvider } from '../services/restaurants.provider.js';
import { nluSessionService } from '../services/nlu-session.service.js';
import { promptManager } from '../services/prompt.service.js';
import config from '../config/index.js';
import { buildFoodGraph } from '../services/conversation/food-graph.manager.js';


// Request validation schema
const NLURequestSchema = z.object({
    text: z.string().min(1).max(500),
    language: z.enum(['he', 'en', 'ar']).default('he'),
    nearMe: z.boolean().optional(),
    userLocation: z.object({ lat: z.number(), lng: z.number() }).optional()
});

// Singletons / lazily resolved instances
const provider = getRestaurantsProvider();

export async function nluParseHandler(req: Request, res: Response) {
    try {
        // Validate request
        const parsed = NLURequestSchema.safeParse(req.body);
        if (!parsed.success) {
            return res.status(400).json({
                error: 'Invalid request',
                details: parsed.error.flatten()
            });
        }

        const { text, language, nearMe, userLocation } = parsed.data as any;
        try { console.log('[NLU] Incoming body nearMe/userLocation:', { nearMe, userLocation }); } catch { }
        const sessionId = req.headers['x-session-id'] as string || `session-${Date.now()}-${Math.random().toString(36).slice(2)}`;
        const t0 = Date.now();

        // Always run FoodGraph orchestrator so grid works regardless of env flags
        const graph = buildFoodGraph({ nlu: nluService as any, session: nluSessionService as any, provider });
        const runPayload = { sessionId, text, language, nearMe: !!nearMe, userLocation: userLocation || undefined } as any;
        try { console.log('[NLU] Graph run payload:', runPayload); } catch { }
        const out = await graph.run(runPayload);

        if (out.policy?.action !== Action.FetchResults) {
            const msg = out.policy?.message
                || (out.policy?.missing?.includes('location')
                    ? (language === 'he'
                        ? 'אפשר לחפש 10 ק"מ סביב המיקום שלך. לאשר גישה למיקום או לרשום עיר?'
                        : language === 'ar'
                            ? 'أقدر أبحث ضمن 10 كم حول موقعك. تسمح بالموقع أو اكتب مدينة؟'
                            : 'I can search 10km around you. Share your location or type a city?')
                    : out.policy?.missing?.includes('city')
                        ? promptManager.get('clarify_city', language)
                        : out.policy?.missing?.includes('maxPrice')
                            ? promptManager.get('clarify_price', language)
                            : promptManager.get('clarify_city', language));
            return res.json({ type: 'clarify', message: msg, missing: out.policy?.missing || [], language });
        }

        const restaurants = (out.results?.restaurants || []).slice(0, config.UI_RESULT_LIMIT).map((r: any) => ({
            name: r.name,
            address: r.address ?? null,
            rating: r.rating ?? null,
            priceLevel: r.priceLevel ?? null,
            placeId: r.placeId ?? null,
            photoUrl: r.photoUrl ?? null,
            location: r.location ?? null,
            types: r.types ?? null,
            website: r.website ?? null,
            dietary: r.dietary ?? null,
        }));
        const meta = out.results?.meta; // preserve provider meta type
        return res.json({
            type: 'results',
            query: {
                city: out.slots?.city!,
                type: out.slots?.type || undefined,
                constraints: out.slots?.maxPrice ? { maxPrice: out.slots?.maxPrice } : undefined,
                language
            },
            restaurants,
            meta: { ...(meta ?? {} as any), nluConfidence: 1 }
        });

        // Use NLU + Policy + Provider to return structured response for Food UI

        /*      const nluRes = await nluService.extractSlots({ text, language });
              // Merge slots with session memory to support follow-ups like "cheaper" or "same city"
              const mergedSlots = nluSessionService.mergeWithSession(sessionId, nluRes.slots as any);
              const policy = nluPolicy.decideContextual(mergedSlots as any, text, language);
      
              // Return clarification if needed
              if (policy.action === Action.AskClarification || policy.action === Action.ClarifyNotFood) {
                  try {
                      console.log('[NLUParse]', {
                          sessionId,
                          language,
                          tookMs: Date.now() - t0,
                          action: policy.action,
                          input: text.slice(0, 120),
                          missing: policy.missingFields || [],
                      });
                  } catch { }
                  const msg = policy.message
                      || (policy.missingFields?.includes('city')
                          ? promptManager.get('clarify_city', language)
                          : policy.missingFields?.includes('maxPrice')
                              ? promptManager.get('clarify_price', language)
                              : promptManager.get('clarify_city', language));
                  // Do not update memory on clarify; wait until we have anchor/results
                  return res.json({
                      type: 'clarify',
                      message: msg,
                      missing: policy.missingFields || [],
                      language
                  });
              }
      
              // Fetch and return results ONLY if city anchor exists
              if (policy.action === Action.FetchResults && nluRes.slots.city) {
                  const dto: any = { city: mergedSlots.city };
                  if (mergedSlots.type) dto.type = mergedSlots.type;
                  if (typeof mergedSlots.maxPrice === 'number') dto.constraints = { maxPrice: mergedSlots.maxPrice };
                  if (mergedSlots.dietary && mergedSlots.dietary.length > 0) {
                      dto.constraints = dto.constraints || {};
                      dto.constraints.dietary = mergedSlots.dietary;
                      console.log(`🍽️ NLU extracted dietary requirements:`, mergedSlots.dietary);
                  } else {
                      console.log(`🍽️ No dietary requirements extracted from: "${text}"`);
                  }
                  dto.language = language as any;
      
                  console.log(`📋 Sending DTO to restaurant service:`, dto);
      
                  const result = await provider.search(dto);
                  // Update session memory after successful fetch
                  nluSessionService.updateSession(sessionId, mergedSlots as any, text);
                  try {
                      console.log('[NLUParse]', {
                          sessionId,
                          language,
                          tookMs: Date.now() - t0,
                          action: policy.action,
                          city: nluRes.slots.city,
                          type: nluRes.slots.type || null,
                          maxPrice: nluRes.slots.maxPrice ?? null,
                          dietary: nluRes.slots.dietary || [],
                          count: (result.restaurants || []).length,
                      });
                  } catch { }
                  const restaurants = (result.restaurants || []).map((r: any) => ({
                      name: r.name,
                      address: r.address ?? null,
                      rating: r.rating ?? null,
                      priceLevel: r.priceLevel ?? null,
                      placeId: r.placeId ?? null,
                      photoUrl: r.photoUrl ?? null,
                      location: r.location ?? null,
                      types: r.types ?? null,
                      website: r.website ?? null,
                  }));
                  const meta: any = {
                      source: result.meta?.source || 'google',
                      nextPageToken: result.meta?.nextPageToken || null,
                      enrichedTopN: result.meta?.enrichedTopN || 0,
                      nluConfidence: nluRes.confidence
                  };
                  if (typeof result.meta?.cached === 'boolean') meta.cached = result.meta.cached;
                  // Optional: concise follow-up to help user narrow/confirm
                  const followUp = await nluService.generateFollowUpMessage({
                      language,
                      slots: mergedSlots as any,
                      resultCount: (result.restaurants || []).length,
                  });
                  return res.json({
                      type: 'results',
                      query: {
                          city: mergedSlots.city!,
                          type: mergedSlots.type || undefined,
                          constraints: mergedSlots.maxPrice ? { maxPrice: mergedSlots.maxPrice } : undefined,
                          language
                      },
                      restaurants,
                      meta,
                      message: followUp || undefined
                  });
              }
      
              // Fallback clarification: ensure we ask for city anchor explicitly
              try {
                  console.log('[NLUParse]', {
                      sessionId,
                      language,
                      tookMs: Date.now() - t0,
                      action: 'clarify_fallback',
                      input: text.slice(0, 120),
                      missing: ['city'],
                  });
              } catch { }
              return res.json({
                  type: 'clarify',
                  message: promptManager.get('clarify_city', language),
                  missing: ['city'],
                  language
              });
         */
    } catch (error: any) {
        console.error('[NLU] Parse handler error:', error);
        return res.status(500).json({ type: 'clarify', message: 'Sorry, an unexpected error occurred.' });
    }
}
