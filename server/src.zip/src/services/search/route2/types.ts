/**
 * ROUTE2 Types
 * 
 * Clean pipeline types for the new search flow
 * Does NOT import V1/V2 orchestrator types
 */

import type { SearchRequest } from '../types/search-request.dto.js';
import type { SearchResponse } from '../types/search-response.dto.js';
import type { SessionService } from '../capabilities/session.service.js';
import type { LLMProvider } from '../../../llm/types.js';

// Re-export for convenience
export type { SearchRequest, SearchResponse };

/**
 * ROUTE2 Pipeline Context
 * Minimal context passed through all stages
 */
export interface Route2Context {
  requestId: string;
  traceId?: string;
  sessionId?: string;
  startTime: number;
  sessionService?: SessionService;
  llmProvider: LLMProvider;
  userLocation?: {
    lat: number;
    lng: number;
  };
  // Region tracking: user (device) vs query (LLM-detected)
  userRegionCode?: 'IL' | 'OTHER';
  queryRegionCode?: 'IL' | 'OTHER';
  regionCodeFinal?: 'IL' | 'OTHER';
}

// Gate2 specific types
export type Gate2Language = 'he' | 'en' | 'ru' | 'ar' | 'fr' | 'es' | 'other';
export type Gate2Route = 'CONTINUE' | 'BYPASS';

/**
 * GATE2 Stage Result
 * Minimal food/language classifier - anchors/modifiers handled by Intent2
 */
export interface Gate2Result {
  isFoodRelated: boolean;
  language: Gate2Language;
  route: Gate2Route;
  confidence: number;
}

export interface Gate2StageOutput {
  gate: Gate2Result;
}

// Intent2 specific types
export type Intent2Mode = 'nearby' | 'landmark' | 'textsearch';
export type Intent2Reason = 'near_me_phrase' | 'explicit_distance_from_me' | 'landmark_detected' | 'default_textsearch' | 'ambiguous';
export type LandmarkType = 'address' | 'poi' | 'street' | 'neighborhood' | 'area' | 'unknown' | null;
export type RadiusSource = 'explicit' | 'default' | null;

/**
 * INTENT2 Stage Result
 * Extracts food and location intent from query with mode classification
 */
export interface Intent2Result {
  language: Gate2Language;
  mode: Intent2Mode;
  reason: Intent2Reason;
  food: {
    raw: string | null;
    canonicalEn: string | null;
  };
  location: {
    isRelative: boolean;
    text: string | null;
    landmarkText: string | null;
    landmarkType: LandmarkType;
  };
  radiusMeters: number | null;
  radiusSource: RadiusSource;
  queryRegionCode: 'IL' | 'OTHER' | null;
  confidence: number;
}

/**
 * ROUTE_LLM Stage Result
 * Determines search mode and parameters
 */
export interface RouteLLMResult {
  mode: 'textsearch' | 'nearbysearch';
  radiusMeters: number;
}

/**
 * GOOGLE_MAPS Stage Result
 * Raw results from Google Places API
 */
export interface GoogleMapsResult {
  results: any[];
}
