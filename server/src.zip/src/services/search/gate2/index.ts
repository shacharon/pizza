/**
 * Gate2 Exports
 * 
 * Standalone deterministic pre-filter stage
 */

export { executeGate2 } from './gate2.service.js';
export type { Gate2Result } from './gate2.service.js';
