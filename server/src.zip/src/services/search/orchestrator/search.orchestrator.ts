/**
 * SearchOrchestrator: The heart of the BFF
 * Coordinates all capability services to provide unified search functionality
 * 
 * Phase 2: Builds TruthState to lock deterministic decisions
 * before passing minimal context to LLM Pass B
 * Phase 7: Production hardening with timeout/retry guards and structured logging
 */

import type {
    IIntentService,
    IGeoResolverService,
    IPlacesProviderService,
    IRankingService,
    ISuggestionService,
    ISessionService,
    ParsedIntent,
    SearchParams,
    AssistPayload,
    ProposedActions,
    ActionDefinition,
    RestaurantResult,
} from '../types/search.types.js';
import type { SearchRequest } from '../types/search-request.dto.js';
import type { SearchResponse } from '../types/search-response.dto.js';
import type { Diagnostics } from '../types/diagnostics.types.js';
import type { TruthState } from '../types/truth-state.types.js';
import { computeResponseMode, buildAssistantContext } from '../types/truth-state.types.js';
import { createSearchResponse } from '../types/search-response.dto.js';
import { QueryComposer } from '../utils/query-composer.js';
import { CityFilterService } from '../filters/city-filter.service.js';
import { StreetDetectorService } from '../detectors/street-detector.service.js';
import { TokenDetectorService } from '../detectors/token-detector.service.js';
import { GranularityClassifier } from '../detectors/granularity-classifier.service.js';
import { ClarificationService } from '../clarification/clarification.service.js';
import { ResultStateEngine } from '../rse/result-state-engine.js';
import { ChatBackService } from '../chatback/chatback.service.js';
import { FailureDetectorService, AssistantNarrationService } from '../assistant/index.js';
import type { ResultGroup, LiveDataVerification } from '../types/search.types.js';
import { calculateOpenNowSummary } from '../utils/opening-hours-summary.js';
import { normalizeToGoogleQuery } from '../utils/google-query-normalizer.js';

// Phase 8: Intent Gate Routing imports
import { IntentGateService } from '../../intent/intent-gate.service.js';
import { IntentFullService } from '../../intent/intent-full.service.js';
import type { IntentGateResult } from '../../intent/intent-gate.types.js';
import type { IntentFullResult } from '../../intent/intent-full.types.js';
import {
    INTENT_GATE_ENABLED,
    INTENT_FORCE_FULL_LLM,
    INTENT_DISABLE_FAST_PATH
} from '../../../config/intent-flags.js';

// V2 Pipeline imports
import { SEARCH_PIPELINE_V2 } from '../../../config/search-pipeline-flags.js';
import { runSearchPipelineV2, createPipelineDependencies, GateAdapter } from '../pipeline/index.js';

// Phase 7: Production hardening imports
import { logger } from '../../../lib/logger/structured-logger.js';
import { withTimeout, isTimeoutError as isTimeout } from '../../../lib/reliability/timeout-guard.js';
import { withRetry } from '../../../lib/reliability/retry-policy.js';
import { ReliabilityConfig } from '../config/reliability.config.js';
import { SearchConfig } from '../config/search.config.js';

// Phase 1: Candidate pool ranking imports
import { ConfidenceService } from '../capabilities/confidence.service.js';
import { getRankingPoolConfig } from '../config/ranking.config.js';

// Phase 2: Search Truth Model imports
import { mapParsedIntentToSearchIntent } from '../mappers/intent-mapper.js';
import type { SearchIntent } from '../types/intent.dto.js';
import { safeValidateIntent } from '../types/intent.dto.js';
import { resolveSearchMode } from '../resolvers/search-mode.resolver.js';
import type { SearchModeResult } from '../resolvers/search-mode.resolver.js';
import { resolveCenter } from '../resolvers/center.resolver.js';
import type { CenterResult } from '../resolvers/center.resolver.js';
import { resolveRadiusMeters } from '../resolvers/radius.resolver.js';
import type { RadiusResult } from '../resolvers/radius.resolver.js';

/**
 * SearchOrchestrator
 * Implements the Backend-for-Frontend pattern for unified search
 */
export class SearchOrchestrator {
    private cityFilter: CityFilterService;
    private streetDetector: StreetDetectorService;
    private tokenDetector: TokenDetectorService;
    private granularityClassifier: GranularityClassifier;
    private clarificationService: ClarificationService;
    private rse: ResultStateEngine;
    private chatBackService: ChatBackService;
    // NEW: AI Assistant services
    private failureDetector: FailureDetectorService;
    private assistantNarration: AssistantNarrationService;
    // Phase 1: Candidate pool ranking
    private confidenceService = new ConfidenceService();
    private poolConfig = getRankingPoolConfig();
    // Phase 8: Intent Gate Routing services
    private intentGateService: IntentGateService;
    private intentFullService: IntentFullService;

    constructor(
        private intentService: IIntentService,
        private geoResolver: IGeoResolverService,
        private placesProvider: IPlacesProviderService,
        private rankingService: IRankingService,
        private suggestionService: ISuggestionService,
        private sessionService: ISessionService,
        private llm?: import('../../../llm/types.js').LLMProvider | null
    ) {
        this.cityFilter = new CityFilterService(5); // Min 5 results before fallback
        this.streetDetector = new StreetDetectorService();
        this.tokenDetector = new TokenDetectorService();
        this.granularityClassifier = new GranularityClassifier();
        this.clarificationService = new ClarificationService();
        this.rse = new ResultStateEngine();
        this.chatBackService = new ChatBackService();
        // NEW: AI Assistant services
        this.failureDetector = new FailureDetectorService();
        this.assistantNarration = new AssistantNarrationService(llm || null);
        // Phase 8: Intent Gate Routing services
        this.intentGateService = new IntentGateService(llm || null);
        this.intentFullService = new IntentFullService(llm || null);

        // Wire up session service to intent service for city caching
        if ('setSessionService' in this.intentService) {
            (this.intentService as any).setSessionService(this.sessionService);
        }
    }

    /**
     * Phase 1: Core search logic - FAST path (no LLM assistant)
     * Returns raw results + metadata + truthState in ~500ms
     * 
     * This method orchestrates intent→geo→provider→filters→ranking→chips
     * but NEVER calls the LLM assistant.
     * 
     * Phase 1 Implementation: Currently wraps search() and strips assistant data.
     * Phase 1.5 will extract the core logic to avoid running the assistant at all.
     * 
     * @param request - Search request from client
     * @param ctx - Search context with requestId, traceId, timings
     * @returns CoreSearchResult with results, truthState, and metadata (NO assistant)
     */
    async searchCore(request: SearchRequest, ctx: import('../types/search.types.js').SearchContext): Promise<import('../types/search.types.js').CoreSearchResult> {
        const { requestId, traceId, startTime } = ctx;

        // NOTE: search_started log moved to controller (single source of truth)

        try {
            // Phase 1.5: Call search() with skipAssistant flag to avoid 3-4s LLM delay
            const fullResponse = await this.search(request, traceId, requestId, true);

            const coreMs = Date.now() - startTime;

            logger.info({
                requestId,
                coreMs,
                resultCount: fullResponse.results.length,
                mode: fullResponse.query.parsed.searchMode
            }, 'search_core_completed');

            // Extract core data (strip assistant)
            const coreResult: import('../types/search.types.js').CoreSearchResult = {
                requestId,
                sessionId: fullResponse.sessionId,
                query: fullResponse.query,
                results: fullResponse.results,
                ...(fullResponse.groups && { groups: fullResponse.groups }),
                chips: fullResponse.chips,
                // Note: truthState not available in SearchResponse, will add in Phase 1.5
                truthState: {} as any, // Placeholder for now
                meta: {
                    tookMs: coreMs,
                    mode: fullResponse.meta.mode,
                    appliedFilters: fullResponse.meta.appliedFilters,
                    confidence: fullResponse.meta.confidence,
                    source: fullResponse.meta.source,
                    failureReason: fullResponse.meta.failureReason,
                    timings: {
                        intentMs: fullResponse.diagnostics?.timings.intentMs || 0,
                        geocodeMs: fullResponse.diagnostics?.timings.geocodeMs || 0,
                        providerMs: fullResponse.diagnostics?.timings.providerMs || 0,
                        rankingMs: fullResponse.diagnostics?.timings.rankingMs || 0
                    },
                    ...(fullResponse.meta.liveData && { liveData: fullResponse.meta.liveData }),
                    ...(fullResponse.meta.cityFilter && { cityFilter: fullResponse.meta.cityFilter }),
                    ...(fullResponse.meta.performance && { performance: fullResponse.meta.performance }),
                    ...(fullResponse.meta.openNowSummary && { openNowSummary: fullResponse.meta.openNowSummary }),
                    ...(fullResponse.meta.capabilities && { capabilities: fullResponse.meta.capabilities })
                }
            };

            return coreResult;

        } catch (error) {
            logger.error({ requestId, error }, 'search_core_failed');
            throw error;
        }
    }

    /**
     * Main search orchestration method
     * Coordinates all services to provide unified search results
     * 
     * Phase 7: Enhanced with structured logging
     * Phase 1: Added requestId parameter (generated by controller)
     * Phase 1: Refactored to call searchCore() + assistant synchronously
     * V2: Routes to new pipeline if SEARCH_PIPELINE_V2 flag is enabled
     * 
     * @param skipGate If true, skip IntentGateService (used when delegated from V2)
     */
    async search(
        request: SearchRequest,
        traceId?: string,
        requestId?: string,
        skipAssistant = false,
        forceV1 = false,
        skipGate = false
    ): Promise<SearchResponse> {
        const startTime = Date.now();
        const finalRequestId = requestId || `req-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

        // Diagnostics tracking
        const timings = {
            intentMs: 0,
            geocodeMs: 0,
            providerMs: 0,
            rankingMs: 0,
            assistantMs: 0,
            totalMs: 0,
        };
        const flags = {
            usedLLMIntent: false,
            usedLLMAssistant: false,
            usedTemplateAssistant: false,
            usedCachedAssistant: false,
            usedTranslation: false,
            liveDataRequested: false,
        };

        // NOTE: search_started log moved to controller (single source of truth)

        logger.debug({ query: request.query }, '[SearchOrchestrator] Starting search');

        // ═══════════════════════════════════════════════════════════
        // V2 PIPELINE ROUTING
        // ═══════════════════════════════════════════════════════════
        // If V2 pipeline is enabled and not forced to V1, delegate to new pipeline
        // Otherwise, continue with V1 flow below
        if (SEARCH_PIPELINE_V2 && !forceV1) {
            logger.info({
                requestId: finalRequestId,
                pipelineVersion: 'v2'
            }, 'pipeline_selected');

            // Create session ID early for V2 pipeline
            const sessionId = request.sessionId || `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

            // Create pipeline dependencies
            const gateAdapter = new GateAdapter(this.intentGateService);
            const deps = createPipelineDependencies(
                gateAdapter,
                this.sessionService, // Pass session service
                // Delegate function that calls V1 flow (force V1 to avoid recursion, skip gate)
                (req, tid, rid, skip) => this.search(req, tid, rid, skip, true, true)
            );

            // Run V2 pipeline
            return runSearchPipelineV2(
                request,
                {
                    requestId: finalRequestId,
                    ...(traceId && { traceId }),
                    sessionId,
                    startTime,
                    skipAssistant,
                    request, // Pass full request
                    sessionService: this.sessionService // Pass session service
                },
                deps
            );
        }

        // V1 flow: Log pipeline selection
        logger.info({
            requestId: finalRequestId,
            pipelineVersion: 'v1',
            ...(skipGate && { delegatedFrom: 'v2' })
        }, 'pipeline_selected');

        try {
            // Step 1: Get or create session (generate ID if not provided)
            const sessionId = request.sessionId || `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
            const session = await this.sessionService.getOrCreate(sessionId);
            logger.debug({ sessionId: session.id }, '[SearchOrchestrator] Session created/retrieved');

            // Step 1.5: Clear context if requested (intent reset)
            if (request.clearContext) {
                // Clear context by resetting the session context
                await this.sessionService.update(session.id, { context: {} as any });
                logger.info({ sessionId: session.id }, '[SearchOrchestrator] Context cleared (intent reset)');
            }

            // Add sessionId to context for city caching
            const contextWithSession = {
                ...session.context,
                sessionId: session.id,
            };

            // ═══════════════════════════════════════════════════════════
            // PHASE 8: INTENT GATE ROUTING LAYER
            // ═══════════════════════════════════════════════════════════

            // Step 2A: Check for categoryHint from UI (skip gate entirely)
            if ((request as any).categoryHint && !INTENT_DISABLE_FAST_PATH) {
                logger.info({
                    requestId: finalRequestId,
                    categoryHint: (request as any).categoryHint
                }, 'search_context_resolved: using_ui_hint');
                flags.usedLLMIntent = false;

                // Build minimal intent from UI hint and continue to legacy flow
                // (Legacy flow will still work with existing intentService)
            }

            // Step 2B: Intent Gate (if enabled and no UI hint)
            let gateResult: IntentGateResult | null = null;
            let fullIntentResult: IntentFullResult | null = null;

            // Skip gate if delegated from V2 (gate already ran in V2 pipeline)
            if (skipGate) {
                logger.debug({
                    requestId: finalRequestId,
                    reason: 'delegated_from_v2'
                }, '[SearchOrchestrator] Skipping gate (already ran in V2)');
                // Continue to legacy intent parsing below
            } else if (INTENT_GATE_ENABLED && !INTENT_FORCE_FULL_LLM && !(request as any).categoryHint) {
                const gateStart = Date.now();

                try {
                    gateResult = await this.intentGateService.analyze(request.query, {
                        requestId: finalRequestId,
                        ...(traceId && { traceId }),
                        sessionId
                    });
                    const gateMs = Date.now() - gateStart;

                    logger.info({
                        requestId: finalRequestId,
                        route: gateResult.route,
                        confidence: gateResult.confidence,
                        hasFood: gateResult.hasFood,
                        hasLocation: gateResult.hasLocation,
                        hasModifiers: gateResult.hasModifiers,
                        language: gateResult.language,
                        durationMs: gateMs
                    }, 'intent_gate_completed');

                    // Route: ASK_CLARIFY → early return
                    if (gateResult.route === 'ASK_CLARIFY') {
                        logger.info({ requestId: finalRequestId }, '[SearchOrchestrator] Gate routed to CLARIFY');
                        return this.buildClarifyResponse({
                            sessionId,
                            reason: gateResult.routeReason,
                            originalQuery: request.query,
                            transparency: {
                                searchMode: 'CLARIFY',
                                searchModeReason: gateResult.routeReason,
                                locationUsed: { text: '', source: 'unknown', coords: null },
                                radiusUsedMeters: 0,
                                radiusSource: 'fallback'
                            }
                        });
                    }

                    // Route: CORE → skip full intent LLM
                    if (gateResult.route === 'CORE' && !INTENT_FORCE_FULL_LLM) {
                        logger.info({ requestId: finalRequestId }, '[SearchOrchestrator] Gate routed to CORE (fast path)');
                        flags.usedLLMIntent = false; // Gate alone doesn't count as full intent

                        // Continue to legacy flow, but it will be fast since we have gate data
                    }

                    // Route: FULL_LLM → run full intent extraction (or skip for simple queries)
                    if (gateResult.route === 'FULL_LLM' || INTENT_FORCE_FULL_LLM) {
                        // Check if this is a fallback due to gate timeout/failure
                        const isGateTimeout = gateResult.routeReason === 'gate_timeout' ||
                            gateResult.routeReason === 'timeout';
                        const isGateError = gateResult.routeReason === 'invalid_schema' ||
                            gateResult.routeReason === 'parse_error';

                        if (isGateTimeout || isGateError) {
                            logger.info({
                                requestId: finalRequestId,
                                traceId,
                                fallbackReason: gateResult.routeReason,
                                confidence: gateResult.confidence
                            }, 'intent_gate_fallback_used');

                            // Smart skip: If gate timed out AND query looks simple, skip full intent
                            // Simple patterns: "X in Y", "X ב Y" (Hebrew city pattern)
                            const simpleQueryPattern = /\bin\b/i.test(request.query) ||
                                /\sב/.test(request.query);

                            if (isGateTimeout && simpleQueryPattern) {
                                logger.info({
                                    requestId: finalRequestId,
                                    traceId,
                                    query: request.query,
                                    reason: 'gate_timeout_simple_query'
                                }, 'intent_full_skipped');

                                // Skip full intent, continue to CORE with legacy parsing
                                flags.usedLLMIntent = false;
                                // Let flow continue to legacy parsing below
                            } else {
                                // Not simple or not timeout - run full intent
                                const fullStart = Date.now();

                                try {
                                    fullIntentResult = await this.intentFullService.extract(
                                        request.query,
                                        contextWithSession,
                                        {
                                            requestId: finalRequestId,
                                            ...(traceId && { traceId }),
                                            sessionId
                                        }
                                    );
                                    timings.intentMs = Date.now() - fullStart;
                                    flags.usedLLMIntent = true; // ONLY set true when full intent runs

                                    logger.info({
                                        requestId: finalRequestId,
                                        confidence: fullIntentResult.confidence,
                                        durationMs: timings.intentMs
                                    }, 'intent_full_completed');

                                } catch (error) {
                                    logger.error({
                                        requestId: finalRequestId,
                                        error: error instanceof Error ? error.message : 'unknown'
                                    }, '[SearchOrchestrator] Full intent extraction failed, falling back to legacy');

                                    // Fallback to legacy intent service
                                    fullIntentResult = null;
                                }
                            }
                        } else {
                            // Normal FULL_LLM route (not from fallback)
                            const fullStart = Date.now();

                            try {
                                fullIntentResult = await this.intentFullService.extract(
                                    request.query,
                                    contextWithSession,
                                    {
                                        requestId: finalRequestId,
                                        ...(traceId && { traceId }),
                                        sessionId
                                    }
                                );
                                timings.intentMs = Date.now() - fullStart;
                                flags.usedLLMIntent = true; // ONLY set true when full intent runs

                                logger.info({
                                    requestId: finalRequestId,
                                    confidence: fullIntentResult.confidence,
                                    durationMs: timings.intentMs
                                }, 'intent_full_completed');

                            } catch (error) {
                                logger.error({
                                    requestId: finalRequestId,
                                    error: error instanceof Error ? error.message : 'unknown'
                                }, '[SearchOrchestrator] Full intent extraction failed, falling back to legacy');

                                // Fallback to legacy intent service
                                fullIntentResult = null;
                            }
                        }
                    }

                } catch (error) {
                    logger.error({
                        requestId: finalRequestId,
                        error: error instanceof Error ? error.message : 'unknown'
                    }, '[SearchOrchestrator] Gate failed, falling back to legacy intent');

                    // Fallback: continue to legacy intent parsing
                    gateResult = null;
                }
            }

            // Step 2C: Legacy intent parsing (fallback or if gate disabled)
            // This runs if:
            // - Gate disabled (INTENT_GATE_ENABLED=false)
            // - Gate failed
            // - Gate routed to CORE (we still need legacy ParsedIntent for compatibility)
            // - No gate result available
            const intentStart = Date.now();
            const { intent, confidence: intentConfidence } = await this.intentService.parse(
                request.query,
                contextWithSession
            );
            let confidence = intentConfidence;

            // Only update timing if we didn't already time full intent
            if (!fullIntentResult) {
                timings.intentMs = Date.now() - intentStart;
            }

            // Set usedLLMIntent flag only if no gate/full intent was used
            if (!gateResult && !fullIntentResult) {
                flags.usedLLMIntent = true;
            }

            flags.liveDataRequested = intent.requiresLiveData || false;

            // Chips/refinements are deterministic operations on the base intent.
            // If user selects a chip (e.g., "Budget", "Open Now"), the frontend
            // applies that filter directly without triggering a new intent parse.

            /**
             * Phase 4: Language Resolution Policy (Single Source of Truth)
             * Priority: session.language > intent.language > default ('en')
             * Once resolved, ParsedIntent.language is AUTHORITATIVE for entire request.
             */
            if (!intent.language || intent.language.length === 0) {
                intent.language = this.resolveLanguage(request, session as any);
                logger.warn({ language: intent.language }, '[SearchOrchestrator] Language not set by intent, using fallback');
            }

            logger.info({
                confidence: confidence.toFixed(2),
                language: intent.language,
                durationMs: timings.intentMs
            }, '[SearchOrchestrator] Intent parsed');

            /**
             * Phase 8b: Gate Canonical Override
             * If Gate routed to CORE and provided English canonical, prefer it over fast-path
             */
            if (gateResult && gateResult.route === 'CORE' && gateResult.food.canonical) {
                const shouldOverride =
                    gateResult.hasFood &&
                    gateResult.confidence >= 0.85 &&
                    gateResult.food.canonical.trim().length > 0;

                if (shouldOverride) {
                    const fromCategory = intent.canonical?.category;
                    intent.canonical = intent.canonical || {};
                    intent.canonical.category = gateResult.food.canonical;

                    logger.info({
                        requestId: finalRequestId,
                        fromCategory,
                        toCategory: intent.canonical.category,
                        gateConfidence: gateResult.confidence,
                        reason: 'gate_canonical_override'
                    }, '[CanonicalOverride] Using gate canonical over fast-path');

                    // Optionally sync location if Gate has better data
                    if (gateResult.location.canonical && !intent.canonical.locationText) {
                        intent.canonical.locationText = gateResult.location.canonical;
                    }
                }
            }

            // ═══════════════════════════════════════════════════════════
            // PHASE 3: PARALLEL LLM INTENT EXTRACTION (Validation)
            // ═══════════════════════════════════════════════════════════
            // TEMPORARILY DISABLED: Adds 4+ seconds to every request
            // TODO: Move to background/async logging or add proper feature flag

            let directSearchIntent: SearchIntent | null = null;
            let directConfidence: number = 0;
            let comparisonResult: import('../comparison/intent-comparator.js').IntentComparison | null = null;

            const ENABLE_PHASE3_VALIDATION = process.env.ENABLE_PHASE3_VALIDATION === 'true';

            if (ENABLE_PHASE3_VALIDATION && this.llm && this.intentService.parseSearchIntent) {
                // Only if explicitly enabled via env var
                try {
                    const directStart = Date.now();
                    const result = await this.intentService.parseSearchIntent(
                        request.query,
                        contextWithSession,
                        this.llm
                    );
                    directSearchIntent = result.intent;
                    directConfidence = result.confidence;
                    const directTime = Date.now() - directStart;

                    logger.info({
                        requestId: finalRequestId,
                        directTime,
                        directConfidence: directConfidence.toFixed(2),
                        foodPresent: directSearchIntent.foodAnchor.present,
                        locationPresent: directSearchIntent.locationAnchor.present
                    }, '[Phase 3] Direct SearchIntent extracted');

                } catch (error) {
                    logger.warn({
                        requestId: finalRequestId,
                        error: error instanceof Error ? error.message : 'unknown'
                    }, '[Phase 3] Direct intent extraction failed, using legacy mapper');
                }
            }

            // ═══════════════════════════════════════════════════════════
            // PHASE 2: MAP TO NEW SCHEMA & DETERMINISTIC RESOLUTION
            // ═══════════════════════════════════════════════════════════

            // Step 2.1: Map legacy ParsedIntent to SearchIntent (temporary)
            const mappedSearchIntent = mapParsedIntentToSearchIntent(
                intent,
                confidence,
                request.query
            );

            // Step 2.1.5: Compare mapped vs direct (Phase 3)
            if (directSearchIntent !== null) {
                const { compareSearchIntents } = await import('../comparison/intent-comparator.js');
                const { comparisonMetrics } = await import('../comparison/comparison-metrics.js');

                comparisonResult = compareSearchIntents(mappedSearchIntent, directSearchIntent);

                // Record for metrics
                comparisonMetrics.record(comparisonResult);

                // Log comparison
                logger.info({
                    requestId: finalRequestId,
                    matched: comparisonResult.matched,
                    differences: comparisonResult.differences.length,
                    confidenceDelta: comparisonResult.confidence.delta.toFixed(3),
                    metrics: comparisonResult.metrics
                }, '[Phase 3] Intent comparison');

                // Log differences if any
                if (comparisonResult.differences.length > 0) {
                    logger.debug({
                        requestId: finalRequestId,
                        differences: comparisonResult.differences.map(d => ({
                            field: d.field,
                            mapped: d.mapped,
                            direct: d.direct,
                            severity: d.severity
                        }))
                    }, '[Phase 3] Intent differences detected');
                }
            }

            // Step 2.1.6: Choose which intent to use (Phase 3 validation: prefer direct)
            const searchIntent = directSearchIntent || mappedSearchIntent;

            logger.debug({
                foodPresent: searchIntent.foodAnchor.present,
                locationPresent: searchIntent.locationAnchor.present,
                nearMe: searchIntent.nearMe
            }, '[SearchOrchestrator] Mapped to SearchIntent');

            // Step 2.2: Validate SearchIntent with Zod
            const validation = safeValidateIntent(searchIntent);
            if (!validation.success) {
                logger.warn({
                    zodError: validation.error.issues
                }, '[SearchOrchestrator] SearchIntent validation failed');

                return this.buildClarifyResponse({
                    sessionId,
                    reason: 'invalid_intent_schema',
                    originalQuery: request.query,
                    transparency: {
                        searchMode: 'CLARIFY',
                        searchModeReason: 'invalid_intent_schema',
                        locationUsed: { text: '', source: 'unknown', coords: null },
                        radiusUsedMeters: 0,
                        radiusSource: 'fallback'
                    },
                    zodError: validation.error
                });
            }

            // Step 2.3: Resolve search mode (FULL / ASSISTED / CLARIFY)
            const modeResult: SearchModeResult = resolveSearchMode(searchIntent, {
                gpsAvailable: Boolean(request.userLocation)
            });

            logger.info({
                searchMode: modeResult.mode,
                reason: modeResult.reason,
                explanation: modeResult.explanation
            }, '[SearchOrchestrator] Search mode resolved');

            // Step 2.4: CLARIFY early return (NO Google call)
            if (modeResult.mode === 'CLARIFY') {
                logger.info('[SearchOrchestrator] CLARIFY mode - returning early without Google call');

                return this.buildClarifyResponse({
                    sessionId,
                    reason: modeResult.reason,
                    searchIntent,
                    originalQuery: request.query,
                    transparency: {
                        searchMode: 'CLARIFY',
                        searchModeReason: modeResult.reason,
                        locationUsed: { text: '', source: 'unknown', coords: null },
                        radiusUsedMeters: 0,
                        radiusSource: 'fallback'
                    }
                });
            }

            // Step 2.5: Resolve center coordinates
            const centerResolverContext: import('../resolvers/center.resolver.js').CenterResolverContext = {
                ...(request.userLocation && { gpsCoords: request.userLocation }),
                geocode: async (text: string) => {
                    const resolved = await this.geoResolver.resolve(text);
                    return resolved ? { lat: resolved.coords.lat, lng: resolved.coords.lng } : null;
                }
            };
            const centerResult: CenterResult = await resolveCenter(searchIntent, centerResolverContext);

            logger.info({
                centerResolved: centerResult.center !== null,
                source: centerResult.source,
                locationText: centerResult.locationText
            }, '[SearchOrchestrator] Center resolved');

            // Step 2.6: Center resolution failed → CLARIFY
            if (!centerResult.center) {
                logger.warn('[SearchOrchestrator] Center resolution failed - returning CLARIFY');

                return this.buildClarifyResponse({
                    sessionId,
                    reason: 'location_resolution_failed',
                    searchIntent,
                    originalQuery: request.query,
                    transparency: {
                        searchMode: 'CLARIFY',
                        searchModeReason: 'location_resolution_failed',
                        locationUsed: {
                            text: centerResult.locationText,
                            source: centerResult.source,
                            coords: null
                        },
                        radiusUsedMeters: 0,
                        radiusSource: 'fallback'
                    }
                });
            }

            // Step 2.7: Resolve radius (hard filter)
            const radiusResult: RadiusResult = resolveRadiusMeters(searchIntent);

            logger.info({
                radiusMeters: radiusResult.radiusMeters,
                source: radiusResult.source,
                explanation: radiusResult.explanation
            }, '[SearchOrchestrator] Radius resolved');

            // ═══════════════════════════════════════════════════════════
            // END PHASE 2 - Continue with existing flow
            // ═══════════════════════════════════════════════════════════

            // Step 2.5: Check for ambiguous city (requires clarification)
            if (intent.location?.cityValidation === 'AMBIGUOUS') {
                logger.warn({ city: intent.location.city }, '[SearchOrchestrator] Ambiguous city - returning clarification');
                const clarification = this.clarificationService.generateConstraintClarification(
                    intent.location.city || 'location',
                    intent.language
                );

                // Phase 2: Build TruthState for early exit
                const failureReason = 'GEOCODING_FAILED' as const;
                const mode = computeResponseMode(failureReason, false); // No weak matches in early exit
                const truthState: TruthState = {
                    intent,
                    results: [],
                    chips: [],
                    failureReason,
                    mode,
                    confidence,
                    language: intent.language,
                    assistantContext: buildAssistantContext({
                        intent,
                        results: [],
                        chips: [],
                        failureReason,
                        mode,
                        liveDataVerified: false,
                    }),
                };

                // Generate assist with minimal context (Performance Policy: Template/Cache/LLM)
                const assistStart = Date.now();
                const assist = await this.assistantNarration.generateFast(
                    truthState.assistantContext,
                    truthState
                );
                timings.assistantMs = Date.now() - assistStart;
                flags.usedTemplateAssistant = assist.usedTemplate || false;
                flags.usedCachedAssistant = assist.fromCache || false;
                flags.usedLLMAssistant = !assist.usedTemplate && !assist.fromCache;

                // Log strategy
                const strategy = assist.usedTemplate ? 'TEMPLATE' : (assist.fromCache ? 'CACHE' : 'LLM');
                logger.info({ strategy, durationMs: timings.assistantMs }, '[SearchOrchestrator] Assistant response generated');

                return createSearchResponse({
                    sessionId,
                    originalQuery: request.query,
                    intent,
                    results: [],
                    chips: [],
                    assist,
                    clarification,
                    requiresClarification: true,
                    meta: {
                        tookMs: Date.now() - startTime,
                        mode: intent.searchMode,
                        appliedFilters: [],
                        confidence,
                        source: 'clarification',
                        failureReason,
                    }
                });
            }

            // Step 2.6: Check for failed city validation
            // Note: Only block if city validation explicitly failed (city doesn't exist)
            // If cityValidation is undefined, it means validation was skipped (API unavailable)
            // In that case, proceed with search using LLM-extracted coordinates
            if (intent.location?.cityValidation === 'FAILED' && intent.location?.city) {
                logger.warn({ city: intent.location.city }, '[SearchOrchestrator] City not found - showing clarification');
                const clarification = this.clarificationService.generateConstraintClarification(
                    intent.location.city!,  // Safe: we checked it exists above
                    intent.language
                );

                // Phase 2: Build TruthState for early exit
                const failureReason = 'GEOCODING_FAILED' as const;
                const mode = computeResponseMode(failureReason, false); // No weak matches in early exit
                const truthState: TruthState = {
                    intent,
                    results: [],
                    chips: [],
                    failureReason,
                    mode,
                    confidence,
                    language: intent.language,
                    assistantContext: buildAssistantContext({
                        intent,
                        results: [],
                        chips: [],
                        failureReason,
                        mode,
                        liveDataVerified: false,
                    }),
                };

                // Generate assist with minimal context (Performance Policy: Template/Cache/LLM)
                const assistStart = Date.now();
                const assist = await this.assistantNarration.generateFast(
                    truthState.assistantContext,
                    truthState
                );
                timings.assistantMs = Date.now() - assistStart;
                flags.usedTemplateAssistant = assist.usedTemplate || false;
                flags.usedCachedAssistant = assist.fromCache || false;
                flags.usedLLMAssistant = !assist.usedTemplate && !assist.fromCache;

                // Log strategy
                const strategy = assist.usedTemplate ? 'TEMPLATE' : (assist.fromCache ? 'CACHE' : 'LLM');
                logger.info({ strategy, durationMs: timings.assistantMs }, '[SearchOrchestrator] Assistant response generated');

                return createSearchResponse({
                    sessionId,
                    originalQuery: request.query,
                    intent,
                    results: [],
                    chips: [],
                    assist,
                    clarification,
                    requiresClarification: true,
                    meta: {
                        tookMs: Date.now() - startTime,
                        mode: intent.searchMode,
                        appliedFilters: [],
                        confidence,
                        source: 'clarification',
                        failureReason,
                    }
                });
            } else if (intent.location?.city && !intent.location?.cityValidation) {
                logger.warn({ city: intent.location.city }, '[SearchOrchestrator] City validation skipped (API unavailable), proceeding with LLM coordinates');
            }

            // Step 2.7: Check for single-token ambiguous queries
            const tokenDetection = this.tokenDetector.detect(request.query, session.context);

            // Step 2.7.1: Check for "open/closed now" keywords and set filter
            if (tokenDetection.constraintType === 'openNow') {
                intent.filters.openNow = true;
                logger.info({ query: request.query }, '[SearchOrchestrator] Open keyword detected, setting openNow: true');
            } else if (tokenDetection.constraintType === 'closedNow') {
                intent.filters.openNow = false;
                logger.info({ query: request.query }, '[SearchOrchestrator] Closed keyword detected, setting openNow: false');
            }

            if (tokenDetection.requiresClarification && tokenDetection.constraintType &&
                tokenDetection.constraintType !== 'openNow' && tokenDetection.constraintType !== 'closedNow') {
                logger.info({ query: request.query, tokenType: tokenDetection.tokenType }, '[SearchOrchestrator] Single-token query detected');

                const clarification = this.clarificationService.generateTokenClarification(
                    request.query,
                    tokenDetection.constraintType as 'parking' | 'kosher' | 'glutenFree' | 'vegan' | 'delivery',
                    intent.language
                );

                // Phase 2: Build TruthState for early exit
                const failureReason = 'LOW_CONFIDENCE' as const;
                const mode = computeResponseMode(failureReason, false); // No weak matches in early exit
                const truthState: TruthState = {
                    intent,
                    results: [],
                    chips: [],
                    failureReason,
                    mode,
                    confidence,
                    language: intent.language,
                    assistantContext: buildAssistantContext({
                        intent,
                        results: [],
                        chips: [],
                        failureReason,
                        mode,
                        liveDataVerified: false,
                    }),
                };

                // Generate assist with minimal context (Performance Policy: Template/Cache/LLM)
                const assistStart = Date.now();
                const assist = await this.assistantNarration.generateFast(
                    truthState.assistantContext,
                    truthState
                );
                timings.assistantMs = Date.now() - assistStart;
                flags.usedTemplateAssistant = assist.usedTemplate || false;
                flags.usedCachedAssistant = assist.fromCache || false;
                flags.usedLLMAssistant = !assist.usedTemplate && !assist.fromCache;

                // Log strategy
                const strategy = assist.usedTemplate ? 'TEMPLATE' : (assist.fromCache ? 'CACHE' : 'LLM');
                logger.info({ strategy, durationMs: timings.assistantMs }, '[SearchOrchestrator] Assistant response generated');

                return createSearchResponse({
                    sessionId,
                    originalQuery: request.query,
                    intent,
                    results: [],
                    chips: [],
                    assist,
                    clarification,
                    requiresClarification: true,
                    meta: {
                        tookMs: Date.now() - startTime,
                        mode: intent.searchMode,
                        appliedFilters: [],
                        confidence: tokenDetection.confidence,
                        source: 'clarification',
                        failureReason,
                    }
                });
            }

            // Step 3: Use resolved center from Phase 2 (no legacy resolveLocation)
            // Phase 2: centerResult already contains the resolved coordinates
            const location = {
                coords: centerResult.center!,  // Safe: we already checked it's not null
                displayName: centerResult.locationText,
                source: centerResult.source === 'gps' ? 'user' as const : 'geocode' as const,
                region: undefined  // TODO: Add region to centerResult if needed
            };
            // Note: geocodeMs already tracked in Phase 2 center resolution
            logger.info({ displayName: location.displayName, source: location.source }, '[SearchOrchestrator] Using Phase 2 resolved center');

            // Step 4: Search for places
            const filters: SearchParams['filters'] = {};

            // Merge filters carefully
            // IMPORTANT: Google Places API doesn't support openNow=false (closed filter)
            // We'll filter for closed restaurants AFTER getting results (derived filter)
            const openNow = request.filters?.openNow ?? intent.filters.openNow;
            const needsClosedFiltering = openNow === false;

            // Only send openNow to Google if it's true (they don't support false)
            if (openNow === true) {
                filters.openNow = true;
            }

            const priceLevel = request.filters?.priceLevel ?? intent.filters.priceLevel;
            if (priceLevel !== undefined) filters.priceLevel = priceLevel;

            const dietary = request.filters?.dietary ?? intent.filters.dietary;
            if (dietary !== undefined) filters.dietary = dietary;

            const mustHave = request.filters?.mustHave ?? intent.filters.mustHave;
            if (mustHave !== undefined) filters.mustHave = mustHave;

            // Query composition strategy: Original language vs English canonical
            // Language-aware: Use original query when language matches region (for authentic local results)
            let queryForGoogle: string;
            const useOriginalLanguage = (intent as any).useOriginalLanguage;

            if (useOriginalLanguage && intent.originalQuery) {
                // Use original query for language-matched searches (e.g., French in France)
                queryForGoogle = intent.originalQuery;
                logger.debug({ queryForGoogle }, '[SearchOrchestrator] Using original language query');
            } else if (intent.canonical?.category) {
                // Canonical category is always English - ensures consistent cross-language results
                const rawCanonical = intent.canonical.category;

                // Apply deterministic normalization: canonical → optimal Google query
                queryForGoogle = normalizeToGoogleQuery(rawCanonical, finalRequestId);

                logger.debug({
                    rawCanonical,
                    queryForGoogle,
                    normalized: rawCanonical !== queryForGoogle
                }, '[SearchOrchestrator] Using normalized canonical category');
            } else {
                // Fallback to composed query (legacy path)
                queryForGoogle = QueryComposer.composeCityQuery(
                    intent.query,
                    intent.location?.city
                );
                logger.warn({ queryForGoogle }, '[SearchOrchestrator] Fallback to composed query');
            }

            const searchParams: SearchParams = {
                query: queryForGoogle,  // English canonical or fallback
                location: location.coords,
                language: intent.languageContext.googleLanguage,  // NEW: Use googleLanguage (he or en)
                ...(intent.location?.region !== undefined && { region: intent.location.region }),  // NEW: Country code from geocoding (e.g., 'fr', 'il', 'us')
                filters,
                mode: intent.searchMode,
                pageSize: 10,
                radius: radiusResult.radiusMeters  // Phase 2: Use deterministic radius (HARD FILTER)
            };

            // Structured logging: Google Places API parameters
            logger.info({
                traceId,
                query: queryForGoogle,
                language: intent.languageContext.googleLanguage,
                region: searchParams.region || null,
                radius: searchParams.radius,
                requestLanguage: intent.languageContext.requestLanguage,
                useOriginalLanguage: useOriginalLanguage || false,
                canonicalCategory: intent.canonical?.category,
                canonicalLocation: intent.canonical?.locationText
            }, 'Google Places API parameters');

            // Enhanced logging: query details with language context
            logger.info({
                targetCity: intent.location?.city || 'none',
                radius: searchParams.radius || 'default',
                googleQuery: queryForGoogle,
                language: intent.languageContext.googleLanguage,
                region: searchParams.region || 'none'
            }, '[SearchOrchestrator] Search parameters');

            // Step 4: Detect if this is a street-level query
            const streetDetection = this.streetDetector.detect(intent, request.query);

            // Step 4.1: Classify search granularity for grouping behavior
            const granularity = this.granularityClassifier.classify(intent, streetDetection);
            intent.granularity = granularity;
            logger.debug({ granularity }, '[SearchOrchestrator] Search granularity determined');

            let groups: ResultGroup[];
            let allResults: RestaurantResult[];
            let googleCallTime: number;

            const googleCallStart = Date.now();

            // Phase 2: Disabled street dual-search (use single deterministic radius)
            // Street queries now use the same single-call flow with radiusResult.radiusMeters
            if (streetDetection.isStreet) {
                logger.info({
                    streetName: streetDetection.streetName,
                    detectionMethod: streetDetection.detectionMethod,
                    radius: radiusResult.radiusMeters
                }, '[SearchOrchestrator] Street query detected - using single call with deterministic radius');
            }

            // Single search call for ALL queries (including streets)
            {
                // Single search (existing flow)
                const rawResults = await this.placesProvider.search(searchParams);
                googleCallTime = Date.now() - googleCallStart;
                timings.providerMs = googleCallTime;

                logger.info({
                    rawResultsCount: rawResults.length,
                    durationMs: googleCallTime
                }, '[SearchOrchestrator] Raw results fetched');

                // DEBUG: Check for duplicates in raw Google results
                const uniqueRawResults = new Set(rawResults.map(r => r.placeId));
                if (uniqueRawResults.size !== rawResults.length) {
                    logger.warn({
                        total: rawResults.length,
                        unique: uniqueRawResults.size,
                        duplicates: rawResults.length - uniqueRawResults.size
                    }, '[DEBUG] Duplicates in RAW Google results!');
                }

                // Phase 1: Log candidate pool metrics
                logger.info({
                    traceId,
                    candidatePoolSize: this.poolConfig.candidatePoolSize,
                    googleResultsCount: rawResults.length
                }, 'Fetched candidate pool');

                allResults = rawResults;

                // Single group for all queries (Phase 2: including streets)
                const groupLabel = streetDetection.isStreet && streetDetection.streetName
                    ? streetDetection.streetName
                    : 'תוצאות';

                groups = [{
                    kind: 'EXACT',
                    label: groupLabel,
                    results: allResults,
                    radiusMeters: radiusResult.radiusMeters  // Phase 2: Use deterministic radius
                }];
            }

            // Phase 8: Calculate opening hours summary BEFORE filtering (for transparency)
            const openNowSummary = calculateOpenNowSummary(allResults);
            logger.info({
                open: openNowSummary.open,
                closed: openNowSummary.closed,
                unknown: openNowSummary.unknown
            }, '[SearchOrchestrator] Opening hours summary');

            // Phase 8: Apply derived filter for "closed now" (Google API doesn't support opennow=false)
            if (needsClosedFiltering) {
                logger.info('[SearchOrchestrator] Applying derived closed now filter (Google API limitation)');
                const beforeCount = allResults.length;
                allResults = allResults.filter(r => r.openNow === false);
                logger.info({ beforeCount, afterCount: allResults.length }, '[SearchOrchestrator] Closed filter applied');

                // Phase 2: Update single group with closed-only results
                if (groups.length > 0 && groups[0]) {
                    groups[0].results = allResults;
                }
            }

            // Step 4.5: Apply city filter to all results (coordinate-based)
            const rankingStart = Date.now();
            const filterStartTime = Date.now();

            // Enable strict mode for explicit city searches (only keep results within city radius)
            const isExplicitCityQuery = Boolean(intent.location?.city) && granularity === 'CITY';
            if (isExplicitCityQuery) {
                logger.info({ city: intent.location?.city }, '[SearchOrchestrator] City filter STRICT mode enabled');
            }

            const filterResult = this.cityFilter.filter(
                allResults,
                intent.location?.city,
                location.coords,  // Pass city center coordinates for distance calculation
                isExplicitCityQuery  // Strict mode for city queries
            );
            const filterTime = Date.now() - filterStartTime;

            logger.info({
                kept: filterResult.kept.length,
                dropped: filterResult.dropped.length,
                durationMs: filterTime
            }, '[SearchOrchestrator] City filter applied');
            if (Object.keys(filterResult.stats.dropReasons).length > 0) {
                logger.debug({ dropReasons: filterResult.stats.dropReasons }, '[SearchOrchestrator] City filter drop reasons');
            }

            // Update groups with filtered results
            if (streetDetection.isStreet) {
                const keptIds = new Set(filterResult.kept.map(r => r.placeId));
                groups = groups.map(group => ({
                    ...group,
                    results: group.results.filter(r => keptIds.has(r.placeId))
                }));
            } else {
                const firstGroup = groups[0];
                if (firstGroup) {
                    firstGroup.results = filterResult.kept;
                }
            }

            // Step 5: Rank filtered results by relevance (Phase 3: with distance scoring)

            // DEBUG: Check for duplicates BEFORE ranking
            const uniqueBeforeRanking = new Set(filterResult.kept.map(r => r.placeId));
            if (uniqueBeforeRanking.size !== filterResult.kept.length) {
                logger.warn({
                    total: filterResult.kept.length,
                    unique: uniqueBeforeRanking.size,
                    duplicates: filterResult.kept.length - uniqueBeforeRanking.size
                }, '[DEBUG] Duplicates detected BEFORE ranking!');
            }

            const rankedResults = this.rankingService.rank(
                filterResult.kept,
                intent
            );
            timings.rankingMs = Date.now() - rankingStart;
            logger.info({ durationMs: timings.rankingMs }, '[SearchOrchestrator] Results ranked');

            // DEBUG: Check for duplicates AFTER ranking
            const uniqueAfterRanking = new Set(rankedResults.map(r => r.placeId));
            if (uniqueAfterRanking.size !== rankedResults.length) {
                logger.warn({
                    total: rankedResults.length,
                    unique: uniqueAfterRanking.size,
                    duplicates: rankedResults.length - uniqueAfterRanking.size,
                    duplicatePlaceIds: rankedResults
                        .map(r => r.placeId)
                        .filter((id, idx, arr) => arr.indexOf(id) !== idx)
                        .slice(0, 5)
                }, '[DEBUG] Duplicates detected AFTER ranking!');
            }

            // Phase 1: Log ranking metrics
            logger.info({
                traceId,
                scoredCandidatesCount: rankedResults.length,
                displaySize: rankedResults.length,
                top1Score: rankedResults[0]?.score,
                top1PlaceId: rankedResults[0]?.placeId,
            }, 'Ranked and filtered candidates');

            // CRITICAL FIX: Deduplicate rankedResults before processing
            // Defensive deduplication: Google API sometimes returns the same place multiple times
            // (e.g., across multiple pages, or matching different internal criteria)
            const seenPlaceIds = new Set<string>();
            const deduplicatedResults = rankedResults.filter(r => {
                if (seenPlaceIds.has(r.placeId)) {
                    logger.warn({
                        placeId: r.placeId,
                        name: r.name,
                        rank: r.rank
                    }, '[Deduplication] Removing duplicate result');
                    return false;
                }
                seenPlaceIds.add(r.placeId);
                return true;
            });

            if (deduplicatedResults.length !== rankedResults.length) {
                logger.warn({
                    original: rankedResults.length,
                    deduplicated: deduplicatedResults.length,
                    removed: rankedResults.length - deduplicatedResults.length
                }, '[Deduplication] Removed duplicate results from ranked set (expected when Google API returns duplicates)');
            }

            // Phase 3: Detect weak matches
            const { strong, weak } = this.detectWeakMatches(deduplicatedResults);

            if (weak.length > 0) {
                logger.warn({
                    weakMatchCount: weak.length,
                    threshold: SearchConfig.ranking.thresholds.weakMatch
                }, '[SearchOrchestrator] Detected weak matches');
                logger.debug({
                    weakMatches: weak.map(r => ({
                        name: r.name,
                        score: r.score?.toFixed(1),
                        rating: r.rating
                    }))
                }, '[SearchOrchestrator] Weak matches dropped');
            }

            // Step 6: Use strong results (or all if no weak matches)
            // Smart display sizing: show all results if we got few, otherwise limit to 10
            const availableResults = strong.length > 0 ? strong : deduplicatedResults;
            const dynamicDisplaySize = availableResults.length < 15
                ? availableResults.length  // Show all if we got <15 results
                : this.poolConfig.displayResultsSize;  // Otherwise use configured limit (10)

            const topResults = availableResults.slice(0, dynamicDisplaySize);

            if (availableResults.length < 15 && availableResults.length > this.poolConfig.displayResultsSize) {
                logger.info({
                    available: availableResults.length,
                    displaying: dynamicDisplaySize,
                    normalLimit: this.poolConfig.displayResultsSize
                }, '[SearchOrchestrator] Showing all results (fewer than 15 available)');
            }

            // DEBUG: Check for duplicates in topResults
            const uniqueTopResults = new Set(topResults.map(r => r.placeId));
            if (uniqueTopResults.size !== topResults.length) {
                logger.error({
                    total: topResults.length,
                    unique: uniqueTopResults.size,
                    duplicates: topResults.length - uniqueTopResults.size,
                    duplicatePlaceIds: topResults
                        .map(r => r.placeId)
                        .filter((id, idx, arr) => arr.indexOf(id) !== idx)
                }, '[DEBUG] DUPLICATES IN topResults! This is the bug!');
            }

            logger.info({
                finalCount: topResults.length,
                strongCount: strong.length,
                weakCount: weak.length,
                totalRanked: deduplicatedResults.length
            }, '[SearchOrchestrator] Final result count');

            // Phase 1: Calculate combined confidence (intent + results quality)
            const confidenceFactors = this.confidenceService.calculateConfidence(
                confidence || 0.7,
                deduplicatedResults
            );

            logger.info({
                traceId,
                intentConf: confidenceFactors.intentConfidence,
                resultsQuality: confidenceFactors.resultsQuality,
                combinedConf: confidenceFactors.combined,
                level: confidenceFactors.level,
            }, 'Calculated combined confidence');

            // Update confidence with combined value
            confidence = confidenceFactors.combined;

            // Phase 3: Group results by search granularity
            if (location.coords) {
                groups = this.groupByGranularity(
                    topResults,
                    location.coords,
                    intent.granularity || 'CITY',
                    intent.location?.city
                );
            } else {
                // No coords: single EXACT group
                groups = [{
                    kind: 'EXACT',
                    label: 'Results',
                    results: topResults,
                }];
            }

            // Step 7: Compute failure reason deterministically (BEFORE chip generation for Phase 5)
            const meta = {
                source: this.placesProvider.getName(),
                cached: false,
                liveData: {
                    openingHoursVerified: false, // TODO: Set true when we fetch Places Details with hours
                    source: 'places_search' as const
                } as LiveDataVerification
            };

            const failureReason = this.failureDetector.computeFailureReason(
                topResults,
                confidence,
                meta,
                intent
            );

            logger.debug({ failureReason }, '[SearchOrchestrator] Failure reason determined');

            // Step 7.5: Compute mode (Phase 5: before chip generation)
            // Phase 5: Pass weak match flag to mode computation
            const mode = computeResponseMode(failureReason, weak.length > 0);
            logger.debug({ mode }, '[SearchOrchestrator] Response mode computed');

            // Step 8: Generate mode-aware suggestion chips
            const chips = this.suggestionService.generate(intent, topResults);
            logger.debug({ chipCount: chips.length }, '[SearchOrchestrator] Suggestion chips generated');

            // Step 8.5: Build TruthState (Phase 2: Lock all deterministic decisions)
            const truthState: TruthState = {
                intent,
                results: topResults,
                chips,
                failureReason,
                mode,
                confidence,
                language: intent.language,
                assistantContext: buildAssistantContext({
                    intent,
                    results: topResults,
                    chips,
                    failureReason,
                    mode,
                    liveDataVerified: meta.liveData.openingHoursVerified,
                }),
            };

            logger.debug({ mode, failureReason }, '[SearchOrchestrator] TruthState built');

            // Step 9: Generate assistant message (Performance Policy: Template/Cache/LLM)
            // Phase 1.5: Skip assistant in async mode (handled by AssistantJobService)
            let assist;
            if (skipAssistant) {
                assist = undefined;
                timings.assistantMs = 0;
            } else {
                const assistStart = Date.now();
                assist = await this.assistantNarration.generateFast(
                    truthState.assistantContext,
                    truthState
                );
                timings.assistantMs = Date.now() - assistStart;
                flags.usedTemplateAssistant = assist.usedTemplate || false;
                flags.usedCachedAssistant = assist.fromCache || false;
                flags.usedLLMAssistant = !assist.usedTemplate && !assist.fromCache;

                // Log strategy
                const strategy = assist.usedTemplate ? 'TEMPLATE' : (assist.fromCache ? 'CACHE' : 'LLM');
                logger.info({ strategy, durationMs: timings.assistantMs }, '[SearchOrchestrator] Assistant response generated');
            }

            // Step 8.5: Generate proposed actions (Human-in-the-Loop pattern)
            // Phase 1.5: Skip in async mode (handled by AssistantJobService recommendations)
            const proposedActions = skipAssistant ? undefined : this.generateProposedActions();
            if (!skipAssistant && proposedActions) {
                logger.debug({
                    quickActionsCount: proposedActions.perResult.length,
                    detailedActionsCount: proposedActions.selectedItem.length
                }, '[SearchOrchestrator] Proposed actions generated');
            }

            // Step 9: Update session with current state
            await this.sessionService.update(session.id, {
                currentIntent: intent,
                currentResults: topResults,
            });

            // Step 10: Build and return response
            const tookMs = Date.now() - startTime;
            timings.totalMs = tookMs;

            // Build diagnostics (only in dev/debug mode)
            const shouldIncludeDiagnostics = process.env.NODE_ENV !== 'production' || request.debug;
            const diagnostics: Diagnostics | undefined = shouldIncludeDiagnostics ? {
                timings,
                counts: {
                    results: topResults.length,
                    chips: chips.length,
                    weakMatches: weak.length,  // Phase 3: Weak matches count
                    ...(streetDetection.isStreet ? {
                        exact: groups[0]?.results.length || 0,
                        nearby: groups[1]?.results.length || 0,
                    } : {}),
                },
                top: {
                    placeIds: topResults.slice(0, 3).map(r => r.placeId),
                    scores: topResults.slice(0, 3).map(r => r.score ?? 0),  // Phase 3: Top scores
                    reasons: topResults.slice(0, 3).map(r => r.matchReasons ?? []),  // Phase 3: Top reasons
                },
                flags: {
                    ...flags,
                    hasWeakMatches: weak.length > 0,  // Phase 3: Weak matches flag
                },
                // Phase 4: Language diagnostics (NEW: Language Normalization)
                language: {
                    requestLanguage: intent.languageContext.requestLanguage,
                    uiLanguage: intent.languageContext.uiLanguage,
                    googleLanguage: intent.languageContext.googleLanguage,
                    ...(intent.location?.region !== undefined && { region: intent.location.region }),
                    ...(intent.canonical?.category !== undefined && { canonicalCategory: intent.canonical.category }),
                    originalQuery: intent.originalQuery,
                },
                // Phase 7: Search granularity
                granularity: intent.granularity,
                // Phase 1: Candidate pool debug info
                candidatePoolSize: this.poolConfig.candidatePoolSize,
                googleResultsCount: allResults.length,
                scoredCandidatesCount: deduplicatedResults.length,
                // Include top scores in DEV only
                ...(this.poolConfig.debugIncludeScore && {
                    topScores: deduplicatedResults.slice(0, 5).map(r => ({
                        placeId: r.placeId,
                        ...(r.score !== undefined && { score: r.score }),
                        ...(r.rank !== undefined && { rank: r.rank }),
                    })),
                }),
                // Phase 3: Intent comparison
                ...(comparisonResult && {
                    intentComparison: {
                        usedDirectIntent: directSearchIntent !== null,
                        matched: comparisonResult.matched,
                        differences: comparisonResult.differences.length,
                        confidenceDelta: comparisonResult.confidence.delta,
                        metrics: comparisonResult.metrics
                    }
                }),
            } : undefined;

            const responseParams: Parameters<typeof createSearchResponse>[0] = {
                sessionId: session.id,
                originalQuery: request.query,
                intent,
                results: topResults,
                groups,  // NEW: Grouped results
                chips,
                assist: assist || { type: 'suggest', message: '', mode: 'NORMAL' },  // Phase 1.5: Fallback for async mode
                ...(proposedActions !== undefined && { proposedActions }),  // Phase 1.5: Optional in async mode
                ...(diagnostics !== undefined && { diagnostics }),  // NEW: Diagnostics
                meta: {
                    tookMs,
                    mode: intent.searchMode,
                    appliedFilters: this.getAppliedFiltersList(intent, request),
                    confidence,
                    source: this.placesProvider.getName(),
                    failureReason,  // REQUIRED: Always set
                    // Additional context
                    originalQuery: request.query,
                    liveData: meta.liveData,
                    // City filter stats
                    cityFilter: intent.location?.city ? {
                        enabled: true,
                        targetCity: intent.location.city,
                        resultsRaw: allResults.length,
                        resultsFiltered: filterResult.kept.length,
                        dropped: filterResult.dropped.length,
                        dropReasons: filterResult.stats.dropReasons,
                    } : {
                        enabled: false,
                        resultsRaw: allResults.length,
                        resultsFiltered: filterResult.kept.length,
                        dropped: filterResult.dropped.length,
                        dropReasons: {},
                    },
                    // Performance breakdown
                    performance: {
                        total: tookMs,
                        googleCall: googleCallTime,
                        cityFilter: filterTime,
                    },
                    // Street grouping stats (Phase 2: simplified for single-call)
                    ...(streetDetection.isStreet ? {
                        streetGrouping: {
                            enabled: true,
                            ...(streetDetection.streetName ? { streetName: streetDetection.streetName } : {}),
                            detectionMethod: streetDetection.detectionMethod,
                            exactCount: groups[0]?.results.length || 0,
                            nearbyCount: 0,  // Phase 2: No dual search, so nearbyCount is 0
                            exactRadius: radiusResult.radiusMeters,
                            nearbyRadius: 0,  // Phase 2: No dual search
                        }
                    } : {}),
                    // Phase 8: Opening hours summary (for transparency)
                    openNowSummary,
                    // Phase 8: API capabilities (for derived filter disclosure)
                    capabilities: {
                        openNowApiSupported: true,
                        closedNowApiSupported: false,
                        closedNowIsDerived: true,
                    },
                    // Phase 2: Transparency metadata (Search Truth Model)
                    transparency: {
                        searchMode: modeResult.mode,
                        searchModeReason: modeResult.reason,
                        locationUsed: {
                            text: centerResult.locationText,
                            source: centerResult.source,
                            coords: centerResult.center
                        },
                        radiusUsedMeters: radiusResult.radiusMeters,
                        radiusSource: radiusResult.source
                    },
                },
            };

            const response = createSearchResponse(responseParams);

            // Phase 7: Structured logging at success exit point
            logger.info({
                requestId,
                timings,
                failureReason: response.meta.failureReason,
                mode: response.assist?.mode,
                resultCount: response.results.length,
                usedLLMIntent: flags.usedLLMIntent,
                usedLLMAssistant: flags.usedLLMAssistant
            }, 'Search completed successfully');

            logger.info({ tookMs }, '[SearchOrchestrator] Search complete');
            if (diagnostics) {
                logger.debug({
                    intentMs: timings.intentMs,
                    geocodeMs: timings.geocodeMs,
                    providerMs: timings.providerMs,
                    rankingMs: timings.rankingMs,
                    assistantMs: timings.assistantMs
                }, '[SearchOrchestrator] Diagnostics timing breakdown');
            }

            // Phase 8: Log cache stats periodically
            if (Math.random() < 0.1) { // 10% of requests
                const { caches } = await import('../../../lib/cache/cache-manager.js');
                logger.debug({
                    cacheStats: {
                        places: caches.placesSearch.getStats(),
                        geocoding: caches.geocoding.getStats()
                    }
                }, '[SearchOrchestrator] Cache statistics');
            }

            return response;

        } catch (error) {
            // Check if request was aborted by client
            const errorMessage = error instanceof Error ? error.message : String(error);
            const isClientAbort = errorMessage.toLowerCase().includes('request aborted') ||
                errorMessage.toLowerCase().includes('aborted') ||
                errorMessage.includes('ECONNRESET');

            if (isClientAbort) {
                // Log as warning, not error - this is expected when clients cancel
                logger.warn({
                    requestId: finalRequestId,
                    query: request.query,
                    reason: 'client_aborted_request',
                    timings
                }, 'client_aborted_request');

                // Don't throw, just return gracefully (or throw a specific error)
                // The controller should handle this appropriately
                throw error;
            }

            // Phase 7: Structured error logging
            logger.error({
                requestId: finalRequestId,
                query: request.query,
                timings
            }, 'Search failed');

            logger.error({ error: errorMessage }, '[SearchOrchestrator] Search failed');
            throw error;
        }
    }

    /**
     * Resolve location to coordinates
     * Handles user location, city names, place names
     */
    private async resolveLocation(
        intent: ParsedIntent,
        request: SearchRequest
    ) {
        // Priority 1: User's explicit location (GPS)
        if (request.userLocation) {
            return await this.geoResolver.resolve(request.userLocation);
        }

        // Priority 2: Intent's location (city/place from query)
        if (intent.location?.city) {
            return await this.geoResolver.resolve(intent.location.city);
        }

        if (intent.location?.place) {
            return await this.geoResolver.resolve(intent.location.place);
        }

        // Priority 3: Intent's coordinates (if LLM extracted them)
        if (intent.location?.coords) {
            return await this.geoResolver.resolve(intent.location.coords);
        }

        // Fallback: return default location
        logger.warn('[SearchOrchestrator] No location found, using fallback');
        return await this.geoResolver.resolve({ lat: 0, lng: 0 });
    }


    /**
     * Generate proposed actions for Human-in-the-Loop pattern
     * Returns quick actions (per-result cards) and detailed actions (selected item)
     * Phase 1: All actions are defined here. Future: LLM-generated based on context
     */
    private generateProposedActions(): ProposedActions {
        // Quick actions shown on each restaurant card
        const perResult: ActionDefinition[] = [
            {
                id: 'directions',
                type: 'GET_DIRECTIONS',
                level: 0,
                label: 'Directions',
                icon: '📍',
                enabled: true,
            },
            {
                id: 'call',
                type: 'CALL_RESTAURANT',
                level: 0,
                label: 'Call',
                icon: '📞',
                enabled: true,
            },
            {
                id: 'save',
                type: 'SAVE_FAVORITE',
                level: 1,
                label: 'Save',
                icon: '❤️',
                enabled: true,
            },
        ];

        // Detailed actions shown when restaurant is selected
        const selectedItem: ActionDefinition[] = [
            {
                id: 'details',
                type: 'VIEW_DETAILS',
                level: 0,
                label: 'View Details',
                icon: 'ℹ️',
                requiresSelection: true,
                enabled: true,
            },
            {
                id: 'directions_full',
                type: 'GET_DIRECTIONS',
                level: 0,
                label: 'Get Directions',
                icon: '📍',
                requiresSelection: true,
                enabled: true,
            },
            {
                id: 'call_full',
                type: 'CALL_RESTAURANT',
                level: 0,
                label: 'Call Restaurant',
                icon: '📞',
                requiresSelection: true,
                enabled: true,
            },
            {
                id: 'menu',
                type: 'VIEW_MENU',
                level: 0,
                label: 'View Menu',
                icon: '📋',
                requiresSelection: true,
                enabled: true,
            },
            {
                id: 'save_full',
                type: 'SAVE_FAVORITE',
                level: 1,
                label: 'Save to Favorites',
                icon: '❤️',
                requiresSelection: true,
                enabled: true,
            },
            {
                id: 'share',
                type: 'SHARE',
                level: 0,
                label: 'Share Restaurant',
                icon: '↗️',
                requiresSelection: true,
                enabled: true,
            },
        ];

        return { perResult, selectedItem };
    }

    /**
     * Phase 2: Build CLARIFY response when search cannot proceed
     * 
     * Used when:
     * - Intent validation fails
     * - Missing required anchors
     * - Center resolution fails
     * 
     * @param params - Clarification parameters
     * @returns SearchResponse with CLARIFY mode and transparency
     */
    private buildClarifyResponse(params: {
        sessionId?: string;
        reason: string;
        searchIntent?: SearchIntent;
        originalQuery?: string;
        transparency: {
            searchMode: 'CLARIFY';
            searchModeReason: string;
            locationUsed: {
                text: string;
                source: 'explicit' | 'gps' | 'geocoded' | 'unknown';
                coords: { lat: number; lng: number } | null;
            };
            radiusUsedMeters: number;
            radiusSource: 'explicit' | 'default_near_me' | 'default_city' | 'default_street' | 'default_poi' | 'fallback';
        };
        zodError?: import('zod').ZodError;
    }): SearchResponse {

        // Determine what's missing
        const missingAnchor = params.reason.includes('food')
            ? 'food'
            : params.reason.includes('location')
                ? 'location'
                : 'unknown';

        // Get language from intent or default
        const language = params.searchIntent?.language || 'en';

        // Build clarification message
        const clarificationMessage = this.getClarificationMessage(missingAnchor, language);

        // Generate session ID if not provided
        const sessionId = params.sessionId || `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

        return createSearchResponse({
            sessionId,
            originalQuery: params.originalQuery || '',
            intent: {} as any, // Minimal intent for CLARIFY mode
            results: [],
            chips: [],
            assist: {
                type: 'clarify',
                mode: 'CLARIFY',
                message: clarificationMessage,
                failureReason: 'LOW_CONFIDENCE'
            },
            meta: {
                tookMs: 0,
                mode: 'textsearch',  // Use a valid SearchMode (Google API type)
                appliedFilters: [],
                confidence: 0.3,
                source: 'none',
                failureReason: 'LOW_CONFIDENCE',
                transparency: params.transparency
            }
        });
    }

    /**
     * Phase 2: Get clarification message based on missing anchor
     * 
     * @param missing - Which anchor is missing ('food' | 'location' | 'unknown')
     * @param language - User's language
     * @returns Localized clarification message
     */
    private getClarificationMessage(
        missing: 'food' | 'location' | 'unknown',
        language: string
    ): string {
        // i18n messages
        const messages = {
            food: {
                en: 'What type of food are you looking for?',
                he: 'איזה סוג אוכל אתה מחפש?',
                ar: 'ما نوع الطعام الذي تبحث عنه؟',
                ru: 'Какую еду вы ищете?'
            },
            location: {
                en: 'Where would you like to search?',
                he: 'איפה תרצה לחפש?',
                ar: 'أين تريد البحث؟',
                ru: 'Где вы хотите искать?'
            },
            unknown: {
                en: 'Could you provide more details about what you\'re looking for?',
                he: 'תוכל לספק פרטים נוספים על מה שאתה מחפש?',
                ar: 'هل يمكنك تقديم المزيد من التفاصيل حول ما تبحث عنه؟',
                ru: 'Не могли бы вы предоставить более подробную информацию о том, что вы ищете?'
            }
        };

        const normalizedLang = language.toLowerCase().slice(0, 2);
        const langKey = ['he', 'ar', 'ru'].includes(normalizedLang) ? normalizedLang : 'en';

        return messages[missing][langKey as 'en' | 'he' | 'ar' | 'ru'] || messages[missing].en;
    }

    /**
     * Phase 4: Resolve language for request
     * Priority: session.language > default ('en')
     */
    private resolveLanguage(request: SearchRequest, session: { context?: { language?: string } }): string {
        // Session language (preserved from previous turn)
        if (session.context?.language && session.context.language.length > 0) {
            return session.context.language;
        }

        // 3. Default to English
        return 'en';
    }

    /**
     * Phase 3: Detect weak matches based on score threshold
     */
    private detectWeakMatches(results: RestaurantResult[]): {
        strong: RestaurantResult[];
        weak: RestaurantResult[];
    } {
        const weakThreshold = SearchConfig.ranking.thresholds.weakMatch;

        const strong = results.filter(r => (r.score ?? 0) >= weakThreshold);
        const weak = results.filter(r => (r.score ?? 0) < weakThreshold);

        return { strong, weak };
    }

    /**
     * Phase 3: Group results by distance from center
     * Makes EXACT/NEARBY grouping consistent for all searches
     */
    private groupResultsByDistance(
        results: RestaurantResult[],
        centerCoords: { lat: number; lng: number },
        exactRadiusM: number = 500,
        nearbyRadiusM: number = 2000
    ): ResultGroup[] {
        const exact: RestaurantResult[] = [];
        const nearby: RestaurantResult[] = [];

        results.forEach(result => {
            if (result.distanceMeters !== undefined) {
                if (result.distanceMeters <= exactRadiusM) {
                    (result as any).groupKind = 'EXACT';
                    exact.push(result);
                } else if (result.distanceMeters <= nearbyRadiusM) {
                    (result as any).groupKind = 'NEARBY';
                    nearby.push(result);
                } else {
                    (result as any).groupKind = 'NEARBY';  // Far results still in NEARBY
                    nearby.push(result);
                }
            } else {
                (result as any).groupKind = 'EXACT';  // Default to EXACT if no distance
                exact.push(result);
            }
        });

        const groups: ResultGroup[] = [];

        if (exact.length > 0) {
            groups.push({
                kind: 'EXACT',
                label: 'Closest Results',
                results: exact,
                radiusMeters: exactRadiusM,
            });
        }

        if (nearby.length > 0) {
            groups.push({
                kind: 'NEARBY',
                label: 'Nearby Options',
                results: nearby,
                radiusMeters: nearbyRadiusM,
            });
        }

        return groups;
    }

    /**
     * Group results by search granularity
     * Applies appropriate distance thresholds based on search type
     */
    private groupByGranularity(
        results: RestaurantResult[],
        centerCoords: { lat: number; lng: number },
        granularity: import('../types/search.types.js').SearchGranularity,
        cityName?: string
    ): ResultGroup[] {

        // CITY: No distance grouping - all results in one group
        if (granularity === 'CITY') {
            results.forEach(r => (r as any).groupKind = 'EXACT');
            return [{
                kind: 'EXACT',
                label: cityName ? `Results in ${cityName}` : 'Results',
                results,
                radiusMeters: 3000
            }];
        }

        // STREET: Tight radii
        if (granularity === 'STREET') {
            return this.groupResultsByDistance(
                results,
                centerCoords,
                SearchConfig.streetSearch.exactRadius,  // 200m
                SearchConfig.streetSearch.nearbyRadius  // 400m
            );
        }

        // LANDMARK: Medium radii
        if (granularity === 'LANDMARK') {
            return this.groupResultsByDistance(
                results,
                centerCoords,
                1000,  // 1km for exact
                3000   // 3km for nearby
            );
        }

        // AREA: Larger radii
        if (granularity === 'AREA') {
            return this.groupResultsByDistance(
                results,
                centerCoords,
                1500,  // 1.5km for exact
                5000   // 5km for nearby
            );
        }

        // Fallback: treat as CITY
        return this.groupByGranularity(results, centerCoords, 'CITY', cityName);
    }

    /**
     * Get list of applied filter strings for metadata
     */
    private getAppliedFiltersList(intent: ParsedIntent, request: SearchRequest): string[] {
        const filters: string[] = [];

        // From intent
        if (intent.filters.openNow) filters.push('opennow');
        if (intent.filters.priceLevel) filters.push(`price:${intent.filters.priceLevel}`);
        if (intent.filters.dietary) filters.push(...intent.filters.dietary.map(d => `dietary:${d}`));
        if (intent.filters.mustHave) filters.push(...intent.filters.mustHave.map(m => `amenity:${m}`));
        if (intent.location?.radius) filters.push(`radius:${intent.location.radius}`);

        // From explicit request filters
        if (request.filters?.openNow) filters.push('opennow');
        if (request.filters?.priceLevel) filters.push(`price:${request.filters.priceLevel}`);
        if (request.filters?.dietary) {
            filters.push(...request.filters.dietary.map(d => `dietary:${d}`));
        }

        return filters;
    }

    /**
     * Get orchestrator statistics
     */
    getStats() {
        return {
            sessionStats: this.sessionService.getStats?.(),
            geocodeStats: this.geoResolver.getCacheStats?.(),
        };
    }
}

