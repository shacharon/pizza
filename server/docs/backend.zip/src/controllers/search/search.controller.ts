/**
 * Unified Search Controller
 * Routes are mounted at /search by the v1 aggregator
 * 
 * Internal routes:
 * - POST /       → /search
 * - GET /stats   → /search/stats
 */

import { Router, type Request, type Response } from 'express';
import { safeParseSearchRequest } from '../../services/search/types/search-request.dto.js';
import { createSearchError } from '../../services/search/types/search-response.dto.js';
import { createLLMProvider } from '../../llm/factory.js';
import { logger } from '../../lib/logger/structured-logger.js';
import { ROUTE2_ENABLED } from '../../config/route2.flags.js';
import { searchRoute2 } from '../../services/search/route2/index.js';
import type { Route2Context } from '../../services/search/route2/index.js';

const router = Router();

/**
 * POST /search
 * Unified search endpoint
 * 
 * Phase 5: Supports both sync (default) and async modes
 * - ?mode=sync (default): Returns full response with assistant (4-6s)
 * - ?mode=async: Returns fast core result, assistant via WebSocket
 */
router.post('/', async (req: Request, res: Response) => {
  // Phase 1: Generate requestId once (source of truth)
  const requestId = `req-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

  try {
    // Validate request
    const validation = safeParseSearchRequest(req.body);

    if (!validation.success) {
      req.log.warn({ requestId, error: validation.error }, 'Invalid search request');
      res.status(400).json(createSearchError(
        'Invalid request',
        'VALIDATION_ERROR',
        validation.error
      ));
      return;
    }

    // Phase 5: Parse mode (sync or async)
    const mode = (req.query.mode as 'sync' | 'async') || 'sync';

    // Phase 8: Log search_started ONCE (single source of truth)
    logger.info({
      requestId,
      query: validation.data!.query,
      mode,
      hasUserLocation: !!validation.data!.userLocation,
      sessionId: validation.data!.sessionId || 'new'
    }, 'search_started');

    req.log.debug({
      requestId,
      query: validation.data!.query,
      mode
    }, 'Search request validated');

    // ROUTE2: New clean pipeline (default enabled)
    if (!ROUTE2_ENABLED) {
      logger.error({ requestId }, 'V1 orchestrator has been removed. Set ROUTE2_ENABLED=true in .env');
      res.status(500).json(createSearchError(
        'V1 orchestrator removed - use ROUTE2',
        'CONFIG_ERROR'
      ));
      return;
    }

    const llm = createLLMProvider();
    if (!llm) {
      logger.error({ requestId }, 'LLM provider not available for ROUTE2');
      res.status(500).json(createSearchError('LLM not configured', 'CONFIG_ERROR'));
      return;
    }

    const route2Context: Route2Context = {
      requestId,
      ...(req.traceId !== undefined && { traceId: req.traceId }),
      ...(validation.data!.sessionId !== undefined && { sessionId: validation.data!.sessionId }),
      startTime: Date.now(),
      llmProvider: llm,
      userLocation: validation.data!.userLocation ?? null
    };

    const response = await searchRoute2(validation.data!, route2Context);

    req.log.info({
      requestId,
      resultCount: response.results.length,
      pipeline: 'route2'
    }, 'Search completed (ROUTE2)');

    res.json(response);

  } catch (error) {
    req.log.error({ requestId, error }, 'Search error');

    res.status(500).json(createSearchError(
      error instanceof Error ? error.message : 'Internal server error',
      'SEARCH_ERROR'
    ));
  }
});

/**
 * GET /search/stats
 * Get orchestrator statistics (for monitoring)
 * Note: V1 orchestrator removed - this endpoint now returns ROUTE2 stats
 */
router.get('/stats', (req: Request, res: Response) => {
  res.json({
    pipeline: 'route2',
    message: 'V1 orchestrator removed - use ROUTE2'
  });
});

export default router;

